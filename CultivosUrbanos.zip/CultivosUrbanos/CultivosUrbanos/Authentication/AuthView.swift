//
//  AuthView.swift
//  CultivosUrbanos
//
//  Created by Jmmy san on 14/4/24.
//

import SwiftUI

struct AuthView: View {
    @Binding var showSignInView: Bool
    
    var body: some View {
        VStack {
            NavigationLink {
                SignInEmailView(showSignInView: $showSignInView)
            } label: {
                Text("Sign In witb Email")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(height: 55)
                    .frame(maxWidth: .infinity)
            }
        }
    }
}

struct AuthView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationStack {
            AuthView(showSignInView: .constant(false))
        }
    }
}
