//
//  SignInEmailView.swift
//  CultivosUrbanos
//
//  Created by Jmmy san on 14/4/24.
//

import SwiftUI


@MainActor
final class SignInEmailViewModel: ObservableObject {
    @Published var email = ""
    @Published var password = ""
    
    func signIn () async throws {
        guard !email.isEmpty, !password.isEmpty else {
            print("Email o contraseña no encontrado.")
            return
        }
        let returnedUserData = try await AuthManager.shared.createUser(email: email, password: password)
    }
    
    func signUp () async throws {
        guard !email.isEmpty, !password.isEmpty else {
            print("Email o contraseña no encontrado.")
            return
        }
        let returnedUserData = try await AuthManager.shared.signInUser(email: email, password: password)
    }
    
}

struct SignInEmailView: View {
    @StateObject private var viewModel = SignInEmailViewModel()
    @Binding var showSignInView: Bool
    var body: some View {
        VStack {
            TextField("Email...", text: $viewModel.email)
                .padding()
                .background(Color.gray.opacity(0.4))
            SecureField("Password...", text: $viewModel.password)
                .padding()
                .background(Color.gray.opacity(0.4))
            Button {
                Task {
                    do {
                        try await viewModel.signUp()
                        showSignInView = false
                        return
                    } catch {
                        print(error)
                    }
                    
                    do {
                        try await viewModel.signIn()
                        showSignInView = false
                        return
                    } catch {
                        print(error)
                    }
                }
            } label: {
                Text("Sign In")
                    .font(.headline)
                    .foregroundColor(.white)
            }
            Spacer()
        }
        .padding()
        .navigationTitle("Sign in with Email")
    }
}

#Preview {
    SignInEmailView(showSignInView: .constant(false))
}
