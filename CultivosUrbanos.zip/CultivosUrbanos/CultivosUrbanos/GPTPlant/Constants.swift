//
//  Constants.swift
//  CultivosUrbanos
//
//  Created by Jmmy san on 14/4/24.
//

import Foundation

enum Constants {
    static let OpenAIAPIKey = "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"
}
