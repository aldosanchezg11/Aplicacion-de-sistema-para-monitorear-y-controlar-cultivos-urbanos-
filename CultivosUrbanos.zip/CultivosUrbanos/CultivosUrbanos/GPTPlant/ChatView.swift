//
//  ChatView.swift
//  CultivosUrbanos
//
//  Created by Jmmy san on 14/4/24.
//

import SwiftUI

struct ChatView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    ChatView()
}
