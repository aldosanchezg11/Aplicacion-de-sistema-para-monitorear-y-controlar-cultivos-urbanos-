//
//  AddPlant.swift
//  CultivosUrbanos
//
//  Created by iOS Lab on 11/04/24.
//

import SwiftUI

struct AddPlant: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    AddPlant()
}
