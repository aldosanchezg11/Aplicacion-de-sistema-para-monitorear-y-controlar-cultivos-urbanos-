//
//  Constants.swift
//  CultivosUrbanos
//
//  Created by Jmmy san on 2/5/24.
//
import Foundation

enum Constants {
    static let OpenAIAPIKey = "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"
}
