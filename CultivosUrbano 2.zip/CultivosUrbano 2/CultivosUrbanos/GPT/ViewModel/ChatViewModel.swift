import Foundation

struct OpenAIResponse: Decodable {
    var choices: [Choice]
    
    struct Choice: Decodable {
        var message: OpenAIMessage
    }
    struct OpenAIMessage: Decodable {
        var role: SenderRole
        var conent: String
    }
}

struct Message: Decodable {
    let id: UUID
    let role: SenderRole
    let content: String
    let createAt: Date
}
