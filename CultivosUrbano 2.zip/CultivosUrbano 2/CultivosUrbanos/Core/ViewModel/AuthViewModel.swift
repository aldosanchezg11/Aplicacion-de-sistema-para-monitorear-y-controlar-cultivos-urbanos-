import Foundation
import Firebase
import FirebaseFirestore
import FirebaseFirestoreSwift


protocol AuthenticationFormProtocol {
    var formisValid: Bool { get }
}

struct Plant: Codable, Identifiable {
    let id: String
    let nombre_planta: String
    var tipoPlanta: String
    
    // Adding CodingKeys to map the Firestore keys to your struct properties
    enum CodingKeys: String, CodingKey {
        case id
        case nombre_planta = "nombre_planta"
        case tipoPlanta = "tipoPlanta"
    }
}

enum PlantError: Error {
    case userNotFound
    case plantCreationFailed(String)
    case plantTypeNotFound
}

enum PlantState: String, Codable {
    case good, caution, danger
    var description: String {
        switch self {
        case .good:
            return "Good"
        case .caution:
            return "Caution"
        case .danger:
            return "Danger"
        }
    }
}

struct SensorRange: Codable {
    var min: Double
    var max: Double
}

struct sensorRanges: Codable {
    var luminosity: SensorRange
    var pHLevels: SensorRange
    var soilMoisture: SensorRange
    var temperature: SensorRange
    
    enum CodingKeys: String, CodingKey {
        case luminosity
        case pHLevels
        case soilMoisture
        case temperature
    }
}



@MainActor
class AuthViewModel: ObservableObject {
    @Published var userSession: FirebaseAuth.User?
    @Published var currentUser: User?
    @Published var hasPlants = false
    @Published var creationSuccessful = false
    @Published var plants: [Plant] = []
    @Published var humidity: Int = 0
    @Published var light: Int = 0
    @Published var pH: Double = 0.0
    @Published var temperature: Double = 0.0
    @Published var messages: [Message] = []
    @Published var currentInput: String = ""
    @Published var plantTypeNames: [String: String] = [:]  // Maps plant type IDs to names
    private let openAIService = OpenAIService()
    @Published var plantCareSuggestions: [String] = []
    @Published var updateId = UUID()
    
    let db = Firestore.firestore()

    private var dbRef = Database.database().reference()
    
    init() {
        self.userSession = Auth.auth().currentUser
        Task {
            await fetchUser()
        }
    }
    
    func getUserID() -> String? {
        // Implement your method to retrieve the current user's ID
        return Auth.auth().currentUser?.uid
    }
    
    func signIn(withEmail email: String, password: String) async throws {
        do {
            let result = try await Auth.auth().signIn(withEmail: email, password: password)
            self.userSession = result.user
            await fetchUser()
        } catch {
            print("DEBUG: fallo al iniciar sesion, error \(error.localizedDescription)")
        }
    }
    
    
    func createUser(withEmail email: String, password: String, fullname: String) async throws {
        do {
            let result = try await Auth.auth().createUser(withEmail: email, password: password)
            self.userSession = result.user
            let user = User(id: result.user.uid, fullname: fullname, email: email)
            let encodedUser = try Firestore.Encoder().encode(user)
            try await Firestore.firestore().collection("usuarios").document(user.id).setData(encodedUser)
            await fetchUser()
        } catch {
            print("DEBUG: fallo al crear un usuario \(error.localizedDescription)")
            
        }
    }
    
    
    func signOut() {
        do {
            try Auth.auth().signOut() //Signs out user in backend
            self.userSession = nil //wipes out user session
            self.currentUser = nil //wipes current user data model
        } catch {
            print("DEBUG: fallo al salir de la sesión, error \(error.localizedDescription)")
        }
        
    }
    
    
    func fetchUser() async {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        guard let snapshot = try? await Firestore.firestore().collection("usuarios").document(uid).getDocument() else { return }
        self.currentUser = try? snapshot.data(as: User.self)
        print("DEBUD: Usuario activo es \(self.currentUser)")
    }
    
    // Fetch all plants available in the database
        func fetchAllPlants() async {
            do {
                let querySnapshot = try await db.collection("plantas")
                    .order(by: "name", descending: true)
                    .getDocuments()

                self.plants = querySnapshot.documents.compactMap { document -> Plant? in
                    try? document.data(as: Plant.self)
                }
                
                updateId = UUID()
                print("Fetched all plants: \(self.plants.count)")
            } catch {
                print("Error fetching all plants: \(error)")
                self.plants = [] // Clear the array if there is an error
            }
        }
    
    // Function to fetch all plants for the current user
    // Fetch plants specific to the current user
    // Fetch plants specific to the current user
    func fetchUserPlants() async {
        guard let user = currentUser else { return }
        let db = Firestore.firestore()
        let plantsRef = db.collection("usuarios").document(user.id).collection("plantas")
        
        do {
            let snapshot = try await plantsRef.getDocuments()
            var fetchedPlants: [Plant] = []
            for document in snapshot.documents {
                var plant = try document.data(as: Plant.self)
                plant.tipoPlanta = plantTypeNames[plant.tipoPlanta] ?? "Unknown"
                fetchedPlants.append(plant)
            }
            DispatchQueue.main.async {
                self.plants = fetchedPlants
            }
        } catch {
            print("Error fetching plants: \(error)")
        }
    }
    
    func fetchPlantTypeNames(for plants: [Plant], completion: @escaping ([Plant]) -> Void) {
        let db = Firestore.firestore()
        var updatedPlants = plants
        let group = DispatchGroup()
        
        for (index, plant) in plants.enumerated() {
            group.enter()
            let plantTypeRef = db.collection("plant_type").document(plant.tipoPlanta)
            plantTypeRef.getDocument { (document, error) in
                defer { group.leave() }
                if let document = document, document.exists {
                    let plantTypeName = document.get("name") as? String ?? "Unknown"
                    updatedPlants[index].tipoPlanta = plantTypeName
                } else {
                    print("Document does not exist or failed to fetch plant type name")
                    updatedPlants[index].tipoPlanta = "Unknown"
                }
            }
        }

        group.notify(queue: .main) {
            completion(updatedPlants)
        }
    }
    
    
    func createPlant(name: String, countryOfOrigin: String, additionalInfo: String, plantType: String) async throws {
        guard let user = self.currentUser else { throw PlantError.userNotFound }
        
        // Fetch the document ID for the specified plantType
        let plantTypeRef = db.collection("plant_type").whereField("name", isEqualTo: plantType).limit(to: 1)
        
        let documents = try await plantTypeRef.getDocuments()
        guard let document = documents.documents.first else {
            throw PlantError.plantTypeNotFound
        }
        
        let plantTypeID = document.documentID
        
        // Store the plant under the specific plant type
        let cropsRef = db.collection("plant_type").document(plantTypeID).collection("crops")
        do {
            // Initially create the document with just the minimal necessary data
            let documentRef = try await cropsRef.addDocument(data: [
                "name": name,
                "countryOfOrigin": countryOfOrigin,
                "additionalInfo": additionalInfo,
                "plantType": plantTypeID
            ])
            
            // Update the plant's ID with the newly created document's ID
            try await cropsRef.document(documentRef.documentID).setData(["id": documentRef.documentID], merge: true)
            
            // Then link this new plant under the user's plant collection
            let userPlantRef = db.collection("usuarios").document(user.id).collection("plantas")
            try await userPlantRef.addDocument(data: [
                "nombre_planta": name,
                "tipoPlanta": plantTypeID,  // Store the plant type ID
                "documentRef": documentRef.documentID,  // Store the reference to the crop document
                "id": documentRef.documentID  // Store the newly assigned document ID
            ])
            self.hasPlants = true // Optionally update local state to indicate the user has plants
        } catch {
            print("Error creating plant: \(error)")
            throw error
        }
    }
}

extension AuthViewModel {
    func fetchSensorRanges(plantType: String, completion: @escaping (Result<sensorRanges, Error>) -> Void) {
        db.collection("plant_type").document(plantType).getDocument { document, error in
            guard let document = document, document.exists else {
                completion(.failure(error ?? NSError(domain: "FetchError", code: -1, userInfo: nil)))
                return
            }
            do {
                let ranges = try document.data(as: sensorRanges.self)
                completion(.success(ranges))
            } catch {
                completion(.failure(error))
            }
        }
    }
    
    private func fetchHumidity() {
            dbRef.child("test/hum").observeSingleEvent(of: .value, with: { snapshot in
                if let value = snapshot.value as? Int {
                    DispatchQueue.main.async {
                        self.humidity = value
                    }
                }
            })
        }
    
    private func fetchLight() {
           dbRef.child("test/light").observeSingleEvent(of: .value, with: { snapshot in
                if let value = snapshot.value as? Int {
                    DispatchQueue.main.async {
                        self.light = value
                    }
                }
            })
        }

        private func fetchPH() {
           dbRef.child("test/pH").observeSingleEvent(of: .value, with: { snapshot in
                if let value = snapshot.value as? Double {
                    DispatchQueue.main.async {
                        self.pH = value
                    }
                }
            })
        }

        private func fetchTemperature() {
           dbRef.child("test/temp").observeSingleEvent(of: .value, with: { snapshot in
                if let value = snapshot.value as? Double {
                    DispatchQueue.main.async {
                        self.temperature = value
                    }
                }
            })
        }
    
    func fetchEnvironmentData() {
            fetchLight()
            fetchPH()
            fetchTemperature()
            fetchHumidity()  // New fetch method for humidity
        }
    
    // Function to handle the received message
    private func processReceivedMessage(response: OpenAIChatResponse?) {
        guard let receivedMessage = response?.choices.last?.message else {
            print("No hay respuesta recivida")
            return
        }
        let message = Message(id: UUID(), role: receivedMessage.role, content: receivedMessage.content, createAt: Date())
        DispatchQueue.main.async {
            self.messages.append(message)
            // If the assistant is the sender, it is assumed to be a plant care suggestion
            if message.role == .assistant {
                self.plantCareSuggestions = self.parseSuggestions(message.content)
            }
        }
    }
    
    // Parse suggestions from the assistant's response
    private func parseSuggestions(_ text: String) -> [String] {
        // Split the text into individual suggestions, can be customized as needed
        let suggestions = text.components(separatedBy: CharacterSet.newlines).filter { !$0.isEmpty }
        return suggestions
    }
    
    // Function to request plant care suggestions
    func askPlantExpert(plantInfo: String) {
        let newMessage = Message(id: UUID(), role: .user, content: plantInfo, createAt: Date())
        messages.append(newMessage)
        
        Task {
            let response = await openAIService.sendMessage(messages: messages)
            processReceivedMessage(response: response)
        }
    }
    
    func sendMessage() {
        let newMessage = Message(id: UUID(), role: .user, content: currentInput, createAt: Date())
        messages.append(newMessage)
        currentInput = ""
        
        Task {
            let response = await openAIService.sendMessage(messages: messages)
            processReceivedMessage(response: response)
        }
    }
    
    // Generate suggestions based on sensor data
    func generateSuggestions() {
        let plantInfo = "Light: \(light) lux, pH: \(pH), Humidity: \(humidity)%, Temperature: \(temperature)°C. Please provide care suggestions."
        askPlantExpert(plantInfo: plantInfo)
    }

    func evaluatePlantState(for plantID: String) async {
        // Fetch the sensor ranges first
        let sensorRangesResult = await fetchSensorRanges(for: plantID)

        switch sensorRangesResult {
        case .success(let ranges):
            // Fetch environmental data
            await fetchEnvironmentData()

            // Since you are in an async context, you can continue without needing to dispatch to main explicitly here
            var cautionCount = 0

            // Evaluate each sensor reading against the ranges
            if Double(self.light) < ranges.luminosity.min || Double(self.light) > ranges.luminosity.max {
                cautionCount += 1
            }
            if self.pH < ranges.pHLevels.min || self.pH > ranges.pHLevels.max {
                cautionCount += 1
            }
            if Double(self.humidity) < ranges.soilMoisture.min || Double(self.humidity) > ranges.soilMoisture.max {
                cautionCount += 1
            }
            if self.temperature < ranges.temperature.min || self.temperature > ranges.temperature.max {
                cautionCount += 1
            }

            // Determine the plant state based on the number of cautions
            let plantState = evaluateCautionCount(cautionCount)
            print("Plant State: \(plantState.description)")

        case .failure(let error):
            print("Failed to fetch sensor ranges: \(error)")
        }
    }

    
    func fetchPlantTypeRef(for plantID: String) async -> String? {
        guard let userID = currentUser?.id else {
            print("UserID not found")
            return nil
        }
        
        let plantDocumentRef = db.collection("usuarios").document(userID).collection("plantas").document(plantID)

        do {
            let documentSnapshot = try await plantDocumentRef.getDocument()
            if let plantTypeRef = documentSnapshot.data()?["documentRef"] as? String {
                print("Fetched plant type reference: \(plantTypeRef)")
                return plantTypeRef
            } else {
                print("Plant type reference not found in document")
                return nil
            }
        } catch {
            print("Failed to fetch plantTypeRef: \(error)")
            return nil
        }
    }



    
    func evaluateCautionCount(_ count: Int) -> PlantState {
        switch count {
        case 0:
            return .good
        case 1...2:
            return .caution
        default:
            return .danger
        }
    }
    
    // Utility function to fetch sensor ranges based on a plant ID
    func fetchSensorRanges(for plantID: String) async -> Result<sensorRanges, Error> {
        do {
            let documentSnapshot = try await db.collection("plant_type").document(plantID).getDocument()
            if let data = documentSnapshot.data(),
               let jsonData = try? JSONSerialization.data(withJSONObject: data, options: []) {
                let ranges = try JSONDecoder().decode(sensorRanges.self, from: jsonData)
                return .success(ranges)
            } else {
                return .failure(PlantError.plantTypeNotFound)
            }
        } catch {
            return .failure(error)
        }
    }


}

