//
//  VincularView.swift
//  CultivosUrbanos
//
//  Created by iOS Lab on 02/05/24.
//

import SwiftUI

struct VincularView: View {
    @State private var selectedKit: String? = nil
    let kits = ["Kit 1 #0001"]

    var body: some View {
        NavigationView {
            VStack {
                List(kits, id: \.self, selection: $selectedKit) { kit in
                    Text(kit)
                        .padding()
                }
                .listStyle(PlainListStyle())
                .navigationTitle("Vincular")
                
                Button(action: {
                    // Refresh or load kits
                }) {
                    Text("Refrescar búsqueda")
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity, minHeight: 44)
                        .background(Color.green)
                        .cornerRadius(10)
                        .padding()
                }
                
                if selectedKit != nil {
                    NavigationLink(destination: AddPlantView()) {
                        Text("Confirmar seleccion")
                            .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.verdeclaro)
                            .cornerRadius(10)
                            .padding(.horizontal)
                    }
                }

                Spacer()

                Button("¿No encuentras tu dispositivo? Soporte al cliente") {
                    // Link to support
                }
                .foregroundColor(.gray)
                .padding()
            }
        }
    }
}


struct VincularView_Preview: PreviewProvider {
    static var previews: some View {
        VincularView()
    }
}
