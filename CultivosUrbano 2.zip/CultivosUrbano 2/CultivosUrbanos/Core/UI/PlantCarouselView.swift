//  PlantCarouselView.swift
//  CultivosUrbanos
//
//  Created by iOS Lab on 15/04/24.
//

import SwiftUI

struct PlantCarouselView: View {
    @EnvironmentObject var viewModel: AuthViewModel
    
    var body: some View {
        NavigationView {
            VStack {
                CustomNavigationBar(title: "MI CULTIVO")
                Spacer()
                
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 20) {
                        ForEach(viewModel.plants, id: \.id) { plant in
                            PlantView(plant: plant)
                        }
                    }
                    .padding()
                }
                .id(viewModel.updateId)
                VStack {
                    Text("Environmental Data")
                        .font(.title2)
                    HStack {
                        VStack {
                            Text("Light: \(viewModel.light)")
                            Text("pH: \(String(format: "%.2f", viewModel.pH))")
                        }
                        VStack {
                            Text("Humidity: \(viewModel.humidity)%")
                            Text("Temperature: \(String(format: "%.2f°C", viewModel.temperature))")
                        }
                    }
                    .font(.headline)
                    .padding()
                }
                .background(Color.secondary.opacity(0.1))
                .cornerRadius(10)
                
                // Suggestion Box
                if !viewModel.plantCareSuggestions.isEmpty {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Sugerencias para cuidado")
                            .font(.title2)
                            .padding(.top)
                        ForEach(viewModel.plantCareSuggestions, id: \.self) { suggestion in
                            Text("• \(suggestion)")
                                .font(.body)
                                .padding(.horizontal)
                        }
                    }
                    .background(Color.blue.opacity(0.1))
                    .cornerRadius(10)
                    .padding()
                }
                
                Spacer()
                
                NavigationLink(destination: AddPlantView()) {
                    Text("Agregar nuevas plantas")
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.green)
                        .cornerRadius(10)
                }
                .padding(.horizontal)
                .padding(.bottom)
            }
            .navigationBarHidden(true)
            .onAppear {
                viewModel.fetchEnvironmentData()
                viewModel.generateSuggestions() // Call this to generate suggestions based on the latest sensor data
            }
        }
    }
}

struct PlantView: View {
    @EnvironmentObject var viewModel: AuthViewModel
    var plant: Plant
    
    @State private var plantState: PlantState = .good // Default state

    var body: some View {
            VStack {
                Text(plant.nombre_planta)
                    .font(.headline)
                
                Image(plantImage(for: plantState))
                    .resizable()
                    .scaledToFit()
                    .frame(width: 150, height: 150)
                
                Text("Estado: \(plantState.description)")
                    .padding()
            }
            .onAppear {
                Task {
                    await evaluateAndUpdatePlantState()
                }
            }
            .padding()
            .background(Color.secondary.opacity(0.1))
            .cornerRadius(10)
        }
        
        func plantImage(for state: PlantState) -> String {
            switch state {
            case .good:
                return "good"
            case .caution:
                return "ok"
            case .danger:
                return "danger"
            }
        }
        
        private func evaluateAndUpdatePlantState() async {
            guard let plantTypeRef = await viewModel.fetchPlantTypeRef(for: plant.id) else {
                print("Failed to fetch plant type reference")
                return
            }
            
            let sensorRangesResult = await viewModel.fetchSensorRanges(for: plantTypeRef)
            switch sensorRangesResult {
            case .success(let ranges):
                await viewModel.fetchEnvironmentData()  // Ensure this fetches and updates the environment data correctly
                DispatchQueue.main.async {  // Ensure UI updates are on the main thread
                    evaluatePlantState(ranges: ranges)
                }
            case .failure(let error):
                print("Failed to fetch sensor ranges: \(error)")
            }
        }
        
        private func evaluatePlantState(ranges: sensorRanges) {
            var cautionCount = 0
            
            if Double(viewModel.light) < ranges.luminosity.min || Double(viewModel.light) > ranges.luminosity.max {
                cautionCount += 1
            }
            if viewModel.pH < ranges.pHLevels.min || viewModel.pH > ranges.pHLevels.max {
                cautionCount += 1
            }
            if Double(viewModel.humidity) < ranges.soilMoisture.min || Double(viewModel.humidity) > ranges.soilMoisture.max {
                cautionCount += 1
            }
            if viewModel.temperature < ranges.temperature.min || viewModel.temperature > ranges.temperature.max {
                cautionCount += 1
            }

            self.plantState = viewModel.evaluateCautionCount(cautionCount)
        }
}


struct SensorView: View {
    var sensorType: String
    var value: String
    
    var body: some View {
        VStack {
            Text(sensorType)
                .font(.caption)
            Text(value)
                .font(.title3)
        }
    }
}

// Create a Preview for the view
struct PlantCarouselView_Previews: PreviewProvider {
    static var previews: some View {
        PlantCarouselView()
            .environmentObject(AuthViewModel())  // Provide an instance of AuthViewModel here
    }
}
