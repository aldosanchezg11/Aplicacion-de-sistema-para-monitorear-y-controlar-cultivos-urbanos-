//
//  MisCultivosView.swift
//  CultivosUrbanos
//
//  Created by Jmmy san on 2/5/24.
//

import SwiftUI

struct MisCultivosView: View {
    @EnvironmentObject var viewModel: AuthViewModel
    
    var body: some View {
        NavigationView {
            List(viewModel.plants) { plant in
                VStack(alignment: .leading) {
                    Text(plant.nombre_planta)
                        .font(.headline)
                        .padding(.bottom, 2)
                    
                    Text("Tipo de planta: \(plant.tipoPlanta)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                        }
            .navigationTitle("Mis Cultivos")
            .onAppear {
                Task {
                    //await viewModel.fetchPlantTypeNames()
                    await viewModel.fetchUserPlants()
                }
            }
        }
    }
}

struct MisCultivosView_Previews: PreviewProvider {
    static var previews: some View {
        MisCultivosView()
            .environmentObject(AuthViewModel()) // Provide an instance of AuthViewModel here
    }
}
