//
//  TutorialView.swift
//  CultivosUrbanos
//
//  Created by Jmmy san on 2/5/24.
//

import SwiftUI

struct TutorialView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    TutorialView()
}
